# Acer — Minecraft

Site do servidor Acer, com tema roxo e vermelho e brasão do Enderman.

- Endereço: `acerSrV.aternos.me`
- Porta Bedrock: `55598`

## Arquivos

- `index.html`: página completa, estilos e interações.
- `assets/brasao-acer.png`: brasão do servidor.

Abra `index.html` no navegador para visualizar.

## GitHub Pages

Em Settings → Pages, escolha **Deploy from a branch**, selecione a branch **main** e a pasta **/ (root)** e salve.
